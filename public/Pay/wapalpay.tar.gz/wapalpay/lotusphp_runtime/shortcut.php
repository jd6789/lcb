<?php
function CE($className)
{
	return LtObjectUtil::singleton($className);
}
